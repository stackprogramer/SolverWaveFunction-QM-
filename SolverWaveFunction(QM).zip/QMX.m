function [ XN] = QMX( N,deltaX,Xstart)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
XN=Xstart+N*deltaX;

end

